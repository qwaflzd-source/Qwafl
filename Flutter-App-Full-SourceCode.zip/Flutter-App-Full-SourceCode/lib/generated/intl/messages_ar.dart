// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ar locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ar';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "aboutProduct": MessageLookupByLibrary.simpleMessage("حول المنتج"),
    "addNew": MessageLookupByLibrary.simpleMessage("أضف جديد"),
    "addNewAddress": MessageLookupByLibrary.simpleMessage("إضافة عنوان جديد"),
    "addToCart": MessageLookupByLibrary.simpleMessage("أضف إلى السلة"),
    "additionalInfo": MessageLookupByLibrary.simpleMessage("معلومات إضافية"),
    "addressLine1": MessageLookupByLibrary.simpleMessage(
      "العنوان الأساسي (الحي والشارع)",
    ),
    "addressLine2": MessageLookupByLibrary.simpleMessage(
      "تفاصيل إضافية للعنوان",
    ),
    "addressTag": MessageLookupByLibrary.simpleMessage("تسمية العنوان"),
    "all": MessageLookupByLibrary.simpleMessage("الكل"),
    "allCategories": MessageLookupByLibrary.simpleMessage("جميع الفئات"),
    "alreadyHaveAnAccount": MessageLookupByLibrary.simpleMessage(
      "هل لديك حساب بالفعل؟",
    ),
    "alwaysWithYourReach": MessageLookupByLibrary.simpleMessage(
      "دائماً في خدمتك",
    ),
    "amount": MessageLookupByLibrary.simpleMessage("المبلغ"),
    "applied": MessageLookupByLibrary.simpleMessage("تم التطبيق"),
    "apply": MessageLookupByLibrary.simpleMessage("تطبيق"),
    "areYouSureWantToCancelOrder": MessageLookupByLibrary.simpleMessage(
      "هل أنت متأكد من إلغاء هذا الطلب؟",
    ),
    "areYouWantOrderAgain": MessageLookupByLibrary.simpleMessage(
      "هل أنت متأكد من طلب هذا مرة أخرى؟",
    ),
    "area": MessageLookupByLibrary.simpleMessage("المنطقة"),
    "buyNow": MessageLookupByLibrary.simpleMessage("اطلب الآن"),
    "cancel": MessageLookupByLibrary.simpleMessage("إلغاء"),
    "cancelOrder": MessageLookupByLibrary.simpleMessage("إلغاء الطلب"),
    "cancelled": MessageLookupByLibrary.simpleMessage("ملغي"),
    "cashOnDelivery": MessageLookupByLibrary.simpleMessage("الدفع عند الاستلام"),
    "cashPaymentDes": MessageLookupByLibrary.simpleMessage(
      "هل أنت متأكد من اختيار الدفع عند الاستلام؟",
    ),
    "categories": MessageLookupByLibrary.simpleMessage("فئات"),
    "changeAddress": MessageLookupByLibrary.simpleMessage("تغيير العنوان"),
    "changePassword": MessageLookupByLibrary.simpleMessage("تغيير كلمة المرور"),
    "checkout": MessageLookupByLibrary.simpleMessage("إتمام الطلب"),
    "clear": MessageLookupByLibrary.simpleMessage("مسح"),
    "close": MessageLookupByLibrary.simpleMessage("إغلاق"),
    "collect": MessageLookupByLibrary.simpleMessage("استلام"),
    "collected": MessageLookupByLibrary.simpleMessage("تم الاستلام"),
    "color": MessageLookupByLibrary.simpleMessage("لون"),
    "confirm": MessageLookupByLibrary.simpleMessage("تأكيد"),
    "confirmNewPass": MessageLookupByLibrary.simpleMessage(
      "تأكيد كلمة المرور الجديدة",
    ),
    "confirmOtp": MessageLookupByLibrary.simpleMessage("تأكيد رمز التحقق"),
    "confirmPassword": MessageLookupByLibrary.simpleMessage(
      "تأكيد كلمة المرور",
    ),
    "contactVia": MessageLookupByLibrary.simpleMessage("التواصل عبر"),
    "continueShopping": MessageLookupByLibrary.simpleMessage("متابعة التصفح"),
    "couponApplyValidation": MessageLookupByLibrary.simpleMessage(
      "يرجى تحديد متجر لتطبيق الرمز الترويجي!",
    ),
    "createNewPass": MessageLookupByLibrary.simpleMessage(
      "إنشاء كلمة مرور جديدة",
    ),
    "createNewPassword": MessageLookupByLibrary.simpleMessage(
      "إنشاء كلمة مرور جديدة",
    ),
    "creditOrDebitCard": MessageLookupByLibrary.simpleMessage(
      "بطاقة ائتمانية أو مدى",
    ),
    "currency": MessageLookupByLibrary.simpleMessage("العملة"),
    "currentPassword": MessageLookupByLibrary.simpleMessage(
      "كلمة المرور الحالية",
    ),
    "customerReview": MessageLookupByLibrary.simpleMessage("رأي العميل"),
    "date": MessageLookupByLibrary.simpleMessage("التاريخ"),
    "dealOfTheDay": MessageLookupByLibrary.simpleMessage("صفقة اليوم"),
    "defaultAddress": MessageLookupByLibrary.simpleMessage("العنوان الافتراضي"),
    "deleteAccount": MessageLookupByLibrary.simpleMessage("حذف الحساب"),
    "deleteAccountDes": MessageLookupByLibrary.simpleMessage(
      "هل أنت متأكد من حذف حسابك؟ لا يمكن التراجع عن هذا الإجراء.",
    ),
    "deleteThis": MessageLookupByLibrary.simpleMessage("حذف"),
    "deliverTo": MessageLookupByLibrary.simpleMessage("التوصيل إلى"),
    "delivered": MessageLookupByLibrary.simpleMessage("تم التسليم"),
    "deliveryAddress": MessageLookupByLibrary.simpleMessage("عنوان التسليم"),
    "deliveryCharge": MessageLookupByLibrary.simpleMessage("رسوم التوصيل"),
    "discount": MessageLookupByLibrary.simpleMessage("الخصم"),
    "dontHaveAccount": MessageLookupByLibrary.simpleMessage("ليس لديك حساب؟"),
    "downloadInvoice": MessageLookupByLibrary.simpleMessage("تحميل الفاتورة"),
    "downloadPaymentSlip": MessageLookupByLibrary.simpleMessage(
      "تحميل إيصال الدفع",
    ),
    "edit": MessageLookupByLibrary.simpleMessage("تعديل"),
    "email": MessageLookupByLibrary.simpleMessage("البريد الإلكتروني"),
    "emailOrPhone": MessageLookupByLibrary.simpleMessage(
      "البريد الإلكتروني أو رقم الجوال",
    ),
    "enFullName": MessageLookupByLibrary.simpleMessage("أدخل الاسم الكامل"),
    "endingIn": MessageLookupByLibrary.simpleMessage("تنتهي في"),
    "enterCurrentPass": MessageLookupByLibrary.simpleMessage(
      "أدخل كلمة المرور الحالية",
    ),
    "enterPhoneNum": MessageLookupByLibrary.simpleMessage("أدخل رقم الجوال"),
    "enterPhoneNumber": MessageLookupByLibrary.simpleMessage("أدخل رقم الجوال"),
    "enterTheEmailAddress": MessageLookupByLibrary.simpleMessage(
      "أدخل البريد الإلكتروني الذي استخدمته عند التسجيل لاستعادة كلمة المرور الخاصة بك. ستصلك رسالة التحقق.",
    ),
    "enterotp": MessageLookupByLibrary.simpleMessage("أدخل رمز التحقق"),
    "estdTime": MessageLookupByLibrary.simpleMessage("الوقت المتوقع للتوصيل"),
    "favorites": MessageLookupByLibrary.simpleMessage("المفضلة"),
    "filter": MessageLookupByLibrary.simpleMessage("تصفية"),
    "flat": MessageLookupByLibrary.simpleMessage("الدور / الشقة"),
    "forgotPassword": MessageLookupByLibrary.simpleMessage("هل نسيت كلمة المرور؟"),
    "fullName": MessageLookupByLibrary.simpleMessage("الاسم الكامل"),
    "getInTouch": MessageLookupByLibrary.simpleMessage("تواصل معنا"),
    "guest": MessageLookupByLibrary.simpleMessage("حساب زائر"),
    "hWtheProduct": MessageLookupByLibrary.simpleMessage("كيف تقيم تجربتك؟"),
    "home": MessageLookupByLibrary.simpleMessage("الرئيسية"),
    "isRequired": MessageLookupByLibrary.simpleMessage("مطلوب!"),
    "justForYou": MessageLookupByLibrary.simpleMessage("مختارة لك"),
    "language": MessageLookupByLibrary.simpleMessage("اللغة"),
    "location": MessageLookupByLibrary.simpleMessage("موقع"),
    "login": MessageLookupByLibrary.simpleMessage("تسجيل الدخول"),
    "logout": MessageLookupByLibrary.simpleMessage("تسجيل الخروج"),
    "logoutDialogDes": MessageLookupByLibrary.simpleMessage(
      "ستحتاج إلى إعادة تسجيل الدخول للوصول إلى حسابك مرة أخرى.",
    ),
    "logoutDialogTitle": MessageLookupByLibrary.simpleMessage(
      "هل أنت متأكد من تسجيل الخروج؟",
    ),
    "makeItDefault": MessageLookupByLibrary.simpleMessage(
      "تعيينه كعنوان افتراضي",
    ),
    "makePayment": MessageLookupByLibrary.simpleMessage("إتمام الدفع"),
    "manageAddress": MessageLookupByLibrary.simpleMessage("إدارة العناوين"),
    "message": MessageLookupByLibrary.simpleMessage("الرسالة"),
    "minimumSpend": MessageLookupByLibrary.simpleMessage("الحد الأدنى للطلب"),
    "more": MessageLookupByLibrary.simpleMessage("المزيد"),
    "mostSelling": MessageLookupByLibrary.simpleMessage("الأكثر مبيعاً"),
    "myCart": MessageLookupByLibrary.simpleMessage("سلتي"),
    "myOrder": MessageLookupByLibrary.simpleMessage("طلباتي"),
    "myProfile": MessageLookupByLibrary.simpleMessage("حسابي"),
    "name": MessageLookupByLibrary.simpleMessage("الاسم"),
    "newPassword": MessageLookupByLibrary.simpleMessage("كلمة المرور الجديدة"),
    "newProduct": MessageLookupByLibrary.simpleMessage("منتج جديد"),
    "no": MessageLookupByLibrary.simpleMessage("لا"),
    "office": MessageLookupByLibrary.simpleMessage("مكتب"),
    "onTheWay": MessageLookupByLibrary.simpleMessage("في الطريق"),
    "orderAgain": MessageLookupByLibrary.simpleMessage("اطلب مرة أخرى"),
    "orderCancelDialogDes": MessageLookupByLibrary.simpleMessage(
      "هل أنت متأكد من إلغاء هذا الطلب؟",
    ),
    "orderDate": MessageLookupByLibrary.simpleMessage("تاريخ الطلب"),
    "orderDetails": MessageLookupByLibrary.simpleMessage("تفاصيل الطلب"),
    "orderId": MessageLookupByLibrary.simpleMessage("رقم الطلب"),
    "orderNow": MessageLookupByLibrary.simpleMessage("اطلب الآن"),
    "orderPlaceDes": MessageLookupByLibrary.simpleMessage(
      "ستصلك رسالة تأكيد الطلب مع تفاصيل طلبك",
    ),
    "orderStatus": MessageLookupByLibrary.simpleMessage("حالة الطلب"),
    "orderSummary": MessageLookupByLibrary.simpleMessage("ملخص الطلب"),
    "orders": MessageLookupByLibrary.simpleMessage("طلباتي"),
    "other": MessageLookupByLibrary.simpleMessage("أخرى"),
    "packSize": MessageLookupByLibrary.simpleMessage("حجم العبوة"),
    "password": MessageLookupByLibrary.simpleMessage("كلمة المرور"),
    "payNow": MessageLookupByLibrary.simpleMessage("ادفع الآن"),
    "payableAmount": MessageLookupByLibrary.simpleMessage("المبلغ المستحق"),
    "paymentFailed": MessageLookupByLibrary.simpleMessage("تعذر الدفع"),
    "paymentFailedDes": MessageLookupByLibrary.simpleMessage(
      "عذراً، تعذرت عملية الدفع. يرجى المحاولة مرة أخرى لاحقاً.",
    ),
    "paymentMethod": MessageLookupByLibrary.simpleMessage("طريقة الدفع"),
    "paymentSuccess": MessageLookupByLibrary.simpleMessage("تم الدفع بنجاح"),
    "paymentSuccessDes": MessageLookupByLibrary.simpleMessage(
      "تمت عملية الدفع بنجاح.",
    ),
    "pending": MessageLookupByLibrary.simpleMessage("قيد الانتظار"),
    "phone": MessageLookupByLibrary.simpleMessage("الجوال"),
    "phoneNumber": MessageLookupByLibrary.simpleMessage("رقم الجوال"),
    "placeOrder": MessageLookupByLibrary.simpleMessage("تأكيد الطلب"),
    "pleaseVerifyYourAccount": MessageLookupByLibrary.simpleMessage(
      "يرجى التحقق من حسابك",
    ),
    "popularProducts": MessageLookupByLibrary.simpleMessage("المنتجات"),
    "postalCode": MessageLookupByLibrary.simpleMessage("رمز بريدي"),
    "price": MessageLookupByLibrary.simpleMessage("السعر"),
    "priceHighToLow": MessageLookupByLibrary.simpleMessage(
      "السعر من الأعلى إلى الأدنى",
    ),
    "priceLowToHigh": MessageLookupByLibrary.simpleMessage(
      "السعر من الأقل إلى الأعلى",
    ),
    "privacyPolicy": MessageLookupByLibrary.simpleMessage("سياسة الخصوصية"),
    "processig": MessageLookupByLibrary.simpleMessage("قيد التنفيذ"),
    "productInCart": MessageLookupByLibrary.simpleMessage(
      "هذا المنتج موجود بالفعل في سلتك!",
    ),
    "productNotFount": MessageLookupByLibrary.simpleMessage("العنصر غير موجود!"),
    "productPrice": MessageLookupByLibrary.simpleMessage("سعر المنتج"),
    "promoCode": MessageLookupByLibrary.simpleMessage(
      "أدخل الرمز الترويجي هنا",
    ),
    "pyment": MessageLookupByLibrary.simpleMessage("الدفع"),
    "readLess": MessageLookupByLibrary.simpleMessage("اقرأ أقل"),
    "readMore": MessageLookupByLibrary.simpleMessage("اقرأ أكثر"),
    "recoverPassDes": MessageLookupByLibrary.simpleMessage(
      "أدخل رقم الجوال الذي استخدمته عند التسجيل لاستعادة كلمة المرور الخاصة بك. ستصلك رسالة التحقق.",
    ),
    "recoverPassword": MessageLookupByLibrary.simpleMessage(
      "استعادة كلمة المرور",
    ),
    "refundPolicy": MessageLookupByLibrary.simpleMessage("سياسة الاسترجاع"),
    "resend": MessageLookupByLibrary.simpleMessage("إعادة إرسال"),
    "resendCode": MessageLookupByLibrary.simpleMessage("إعادة إرسال الرمز خلال"),
    "review": MessageLookupByLibrary.simpleMessage("مراجعة"),
    "save": MessageLookupByLibrary.simpleMessage("حفظ"),
    "savedAddress": MessageLookupByLibrary.simpleMessage("العنوان المحفوظ"),
    "seachSeller": MessageLookupByLibrary.simpleMessage(
      "ابحث عن متجر أو مقدم خدمة",
    ),
    "searchCountryName": MessageLookupByLibrary.simpleMessage(
      "البحث عن اسم الدولة",
    ),
    "searchProduct": MessageLookupByLibrary.simpleMessage(
      "البحث عن منتجات أو خدمات",
    ),
    "select": MessageLookupByLibrary.simpleMessage("اختيار"),
    "send": MessageLookupByLibrary.simpleMessage("إرسال"),
    "sendOtp": MessageLookupByLibrary.simpleMessage("إرسال رمز التحقق"),
    "serviceItem": MessageLookupByLibrary.simpleMessage("عنصر الخدمة"),
    "setPassword": MessageLookupByLibrary.simpleMessage("ضبط كلمة المرور"),
    "shopSelectValidation": MessageLookupByLibrary.simpleMessage(
      "يرجى تحديد متجر لإتمام الطلب!",
    ),
    "shoppingFrom": MessageLookupByLibrary.simpleMessage("الطلب من"),
    "shops": MessageLookupByLibrary.simpleMessage("المتاجر"),
    "signUp": MessageLookupByLibrary.simpleMessage("إنشاء حساب"),
    "signUpToContinue": MessageLookupByLibrary.simpleMessage(
      "يرجى إنشاء حساب لمواصلة الاستخدام",
    ),
    "similarProducts": MessageLookupByLibrary.simpleMessage("منتجات مماثلة"),
    "size": MessageLookupByLibrary.simpleMessage("مقاس"),
    "skip": MessageLookupByLibrary.simpleMessage("تخطي"),
    "sortBy": MessageLookupByLibrary.simpleMessage("ترتيب حسب"),
    "startWriting": MessageLookupByLibrary.simpleMessage("ابدأ بالكتابة..."),
    "status": MessageLookupByLibrary.simpleMessage("الحالة"),
    "storeVoucher": MessageLookupByLibrary.simpleMessage("قسيمة المتجر"),
    "subTotal": MessageLookupByLibrary.simpleMessage("المجموع الفرعي"),
    "subject": MessageLookupByLibrary.simpleMessage("الموضوع"),
    "submit": MessageLookupByLibrary.simpleMessage("إرسال"),
    "support": MessageLookupByLibrary.simpleMessage("الدعم الفني"),
    "termsCondistions": MessageLookupByLibrary.simpleMessage("الشروط والأحكام"),
    "themeMode": MessageLookupByLibrary.simpleMessage("وضع المظهر"),
    "toBePaid": MessageLookupByLibrary.simpleMessage("المبلغ المطلوب دفعه"),
    "topSeller": MessageLookupByLibrary.simpleMessage("الأفضل مبيعاً"),
    "totalAmount": MessageLookupByLibrary.simpleMessage("المبلغ الإجمالي"),
    "type": MessageLookupByLibrary.simpleMessage("النوع"),
    "typeConfirmSecretPassword": MessageLookupByLibrary.simpleMessage(
      "أدخل كلمة المرور الجديدة وأكدها لحسابك.",
    ),
    "updatePassword": MessageLookupByLibrary.simpleMessage("تحديث كلمة المرور"),
    "updateProfile": MessageLookupByLibrary.simpleMessage("تحديث الملف الشخصي"),
    "ur_order_id": MessageLookupByLibrary.simpleMessage(
      "رقم طلبك هو: ",
    ),
    "validity": MessageLookupByLibrary.simpleMessage("الصلاحية حتى"),
    "verification": MessageLookupByLibrary.simpleMessage("التحقق"),
    "verifyNow": MessageLookupByLibrary.simpleMessage("تحقق الآن"),
    "viewMore": MessageLookupByLibrary.simpleMessage("عرض المزيد"),
    "vistiStore": MessageLookupByLibrary.simpleMessage(
      "زيارة المتجر أو المنشأة",
    ),
    "voucherFrom": MessageLookupByLibrary.simpleMessage("قسيمة من:"),
    "voucherNotAvailable": MessageLookupByLibrary.simpleMessage(
      "لم يتم العثور على قسائم لهذا المتجر!",
    ),
    "weSentOtpEmail": MessageLookupByLibrary.simpleMessage(
      "لقد أرسلنا رمز OTP إلى بريدك الإلكتروني",
    ),
    "weSentOtpPhone": MessageLookupByLibrary.simpleMessage(
      "لقد أرسلنا رمز OTP إلى رقم جوالك",
    ),
    "welcomeBack": MessageLookupByLibrary.simpleMessage("مرحباً بعودتك!"),
    "wishlist": MessageLookupByLibrary.simpleMessage("المفضلة"),
    "writeSATP": MessageLookupByLibrary.simpleMessage(
      "اكتب ملاحظتك أو تقييمك هنا",
    ),
    "writeSubjectHere": MessageLookupByLibrary.simpleMessage(
      "اكتب الموضوع هنا",
    ),
    "yes": MessageLookupByLibrary.simpleMessage("نعم"),
    "youAreNotLoggedIn": MessageLookupByLibrary.simpleMessage(
      "لست مسجلاً للدخول. يرجى تسجيل الدخول أولاً!",
    ),
    "yourCartIsEmpty": MessageLookupByLibrary.simpleMessage(
      "السلة فارغة!",
    ),
    "yourOrderHasBeenPlaced": MessageLookupByLibrary.simpleMessage(
      "لقد تم تأكيد طلبك بنجاح",
    ),
    "yourOrderIdIs": MessageLookupByLibrary.simpleMessage(
      "رقم الطلب الخاص بك هو",
    ),
  };
}
