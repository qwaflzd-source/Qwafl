// dart format width=80

/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: deprecated_member_use,directives_ordering,implicit_dynamic_list_literal,unnecessary_import

import 'package:flutter/widgets.dart';

class $AssetsJsonGen {
  const $AssetsJsonGen();

  /// File path: assets/json/countries.json
  String get countries => 'assets/json/countries.json';

  /// List of all assets
  List<String> get values => [countries];
}

class $AssetsPngGen {
  const $AssetsPngGen();

  /// File path: assets/png/banner_image.png
  AssetGenImage get bannerImage =>
      const AssetGenImage('assets/png/banner_image.png');

  /// File path: assets/png/call.png
  AssetGenImage get call => const AssetGenImage('assets/png/call.png');

  /// File path: assets/png/card.png
  AssetGenImage get card => const AssetGenImage('assets/png/card.png');

  /// File path: assets/png/cash.png
  AssetGenImage get cash => const AssetGenImage('assets/png/cash.png');

  /// File path: assets/png/confirm_otp.png
  AssetGenImage get confirmOtp =>
      const AssetGenImage('assets/png/confirm_otp.png');

  /// File path: assets/png/empty_cart.png
  AssetGenImage get emptyCart =>
      const AssetGenImage('assets/png/empty_cart.png');

  /// File path: assets/png/favicon.png
  AssetGenImage get favicon => const AssetGenImage('assets/png/favicon.png');

  /// File path: assets/png/fire.png
  AssetGenImage get fire => const AssetGenImage('assets/png/fire.png');

  /// File path: assets/png/flash-sale-bg.jpg
  AssetGenImage get flashSaleBg =>
      const AssetGenImage('assets/png/flash-sale-bg.jpg');

  /// File path: assets/png/flash_deal_bg.png
  AssetGenImage get flashDealBg =>
      const AssetGenImage('assets/png/flash_deal_bg.png');

  /// File path: assets/png/heart.png
  AssetGenImage get heart => const AssetGenImage('assets/png/heart.png');

  /// File path: assets/png/messenger.png
  AssetGenImage get messenger =>
      const AssetGenImage('assets/png/messenger.png');

  /// File path: assets/png/no_internet_connection.png
  AssetGenImage get noInternetConnection =>
      const AssetGenImage('assets/png/no_internet_connection.png');

  /// File path: assets/png/onboarding_one.png
  AssetGenImage get onboardingOne =>
      const AssetGenImage('assets/png/onboarding_one.png');

  /// File path: assets/png/onboarding_three.png
  AssetGenImage get onboardingThree =>
      const AssetGenImage('assets/png/onboarding_three.png');

  /// File path: assets/png/onboarding_two.png
  AssetGenImage get onboardingTwo =>
      const AssetGenImage('assets/png/onboarding_two.png');

  /// File path: assets/png/placeholder_image.png
  AssetGenImage get placeholderImage =>
      const AssetGenImage('assets/png/placeholder_image.png');

  /// File path: assets/png/searce_result.png
  AssetGenImage get searceResult =>
      const AssetGenImage('assets/png/searce_result.png');

  /// File path: assets/png/splash_logo.png
  AssetGenImage get splashLogo =>
      const AssetGenImage('assets/png/splash_logo.png');

  /// File path: assets/png/tik.png
  AssetGenImage get tik => const AssetGenImage('assets/png/tik.png');

  /// File path: assets/png/whatsapp.png
  AssetGenImage get whatsapp => const AssetGenImage('assets/png/whatsapp.png');

  /// List of all assets
  List<AssetGenImage> get values => [
        bannerImage,
        call,
        card,
        cash,
        confirmOtp,
        emptyCart,
        favicon,
        fire,
        flashSaleBg,
        flashDealBg,
        heart,
        messenger,
        noInternetConnection,
        onboardingOne,
        onboardingThree,
        onboardingTwo,
        placeholderImage,
        searceResult,
        splashLogo,
        tik,
        whatsapp
      ];
}

class $AssetsSvgGen {
  const $AssetsSvgGen();

  /// File path: assets/svg/active_bag.svg
  String get activeBag => 'assets/svg/active_bag.svg';

  /// File path: assets/svg/active_categories.svg
  String get activeCategories => 'assets/svg/active_categories.svg';

  /// File path: assets/svg/active_favorite.svg
  String get activeFavorite => 'assets/svg/active_favorite.svg';

  /// File path: assets/svg/active_home.svg
  String get activeHome => 'assets/svg/active_home.svg';

  /// File path: assets/svg/active_more.svg
  String get activeMore => 'assets/svg/active_more.svg';

  /// File path: assets/svg/active_radio.svg
  String get activeRadio => 'assets/svg/active_radio.svg';

  /// File path: assets/svg/active_shop.svg
  String get activeShop => 'assets/svg/active_shop.svg';

  /// File path: assets/svg/active_support.svg
  String get activeSupport => 'assets/svg/active_support.svg';

  /// File path: assets/svg/arrow-left.svg
  String get arrowLeft => 'assets/svg/arrow-left.svg';

  /// File path: assets/svg/arrow-right.svg
  String get arrowRight => 'assets/svg/arrow-right.svg';

  /// File path: assets/svg/bag.svg
  String get bag => 'assets/svg/bag.svg';

  /// File path: assets/svg/blog.svg
  String get blog => 'assets/svg/blog.svg';

  /// File path: assets/svg/box-check.svg
  String get boxCheck => 'assets/svg/box-check.svg';

  /// File path: assets/svg/cancel_icon.svg
  String get cancelIcon => 'assets/svg/cancel_icon.svg';

  /// File path: assets/svg/cart.svg
  String get cart => 'assets/svg/cart.svg';

  /// File path: assets/svg/cash.svg
  String get cash => 'assets/svg/cash.svg';

  /// File path: assets/svg/clock.svg
  String get clock => 'assets/svg/clock.svg';

  /// File path: assets/svg/confirm_otp.svg
  String get confirmOtp => 'assets/svg/confirm_otp.svg';

  /// File path: assets/svg/cuppon.svg
  String get cuppon => 'assets/svg/cuppon.svg';

  /// File path: assets/svg/currency.svg
  String get currency => 'assets/svg/currency.svg';

  /// File path: assets/svg/done_icon.svg
  String get doneIcon => 'assets/svg/done_icon.svg';

  /// File path: assets/svg/edit.svg
  String get edit => 'assets/svg/edit.svg';

  /// File path: assets/svg/envelope.svg
  String get envelope => 'assets/svg/envelope.svg';

  /// File path: assets/svg/eye.svg
  String get eye => 'assets/svg/eye.svg';

  /// File path: assets/svg/facebook.svg
  String get facebook => 'assets/svg/facebook.svg';

  /// File path: assets/svg/fill_location.svg
  String get fillLocation => 'assets/svg/fill_location.svg';

  /// File path: assets/svg/filter.svg
  String get filter => 'assets/svg/filter.svg';

  /// File path: assets/svg/fire.svg
  String get fire => 'assets/svg/fire.svg';

  /// File path: assets/svg/gift.svg
  String get gift => 'assets/svg/gift.svg';

  /// File path: assets/svg/grid.svg
  String get grid => 'assets/svg/grid.svg';

  /// File path: assets/svg/heart.svg
  String get heart => 'assets/svg/heart.svg';

  /// File path: assets/svg/image.svg
  String get image => 'assets/svg/image.svg';

  /// File path: assets/svg/inactive_bag.svg
  String get inactiveBag => 'assets/svg/inactive_bag.svg';

  /// File path: assets/svg/inactive_categories.svg
  String get inactiveCategories => 'assets/svg/inactive_categories.svg';

  /// File path: assets/svg/inactive_favorite.svg
  String get inactiveFavorite => 'assets/svg/inactive_favorite.svg';

  /// File path: assets/svg/inactive_home.svg
  String get inactiveHome => 'assets/svg/inactive_home.svg';

  /// File path: assets/svg/inactive_more.svg
  String get inactiveMore => 'assets/svg/inactive_more.svg';

  /// File path: assets/svg/inactive_shop.svg
  String get inactiveShop => 'assets/svg/inactive_shop.svg';

  /// File path: assets/svg/inactive_support.svg
  String get inactiveSupport => 'assets/svg/inactive_support.svg';

  /// File path: assets/svg/key.svg
  String get key => 'assets/svg/key.svg';

  /// File path: assets/svg/linked_in.svg
  String get linkedIn => 'assets/svg/linked_in.svg';

  /// File path: assets/svg/list.svg
  String get list => 'assets/svg/list.svg';

  /// File path: assets/svg/location.svg
  String get location => 'assets/svg/location.svg';

  /// File path: assets/svg/location_purple.svg
  String get locationPurple => 'assets/svg/location_purple.svg';

  /// File path: assets/svg/logout.svg
  String get logout => 'assets/svg/logout.svg';

  /// File path: assets/svg/message-text.svg
  String get messageText => 'assets/svg/message-text.svg';

  /// File path: assets/svg/message.svg
  String get message => 'assets/svg/message.svg';

  /// File path: assets/svg/notification-white.svg
  String get notificationWhite => 'assets/svg/notification-white.svg';

  /// File path: assets/svg/notification.svg
  String get notification => 'assets/svg/notification.svg';

  /// File path: assets/svg/phone.svg
  String get phone => 'assets/svg/phone.svg';

  /// File path: assets/svg/pinterest.svg
  String get pinterest => 'assets/svg/pinterest.svg';

  /// File path: assets/svg/privacy.svg
  String get privacy => 'assets/svg/privacy.svg';

  /// File path: assets/svg/profile.svg
  String get profile => 'assets/svg/profile.svg';

  /// File path: assets/svg/radio.svg
  String get radio => 'assets/svg/radio.svg';

  /// File path: assets/svg/radio_icon.svg
  String get radioIcon => 'assets/svg/radio_icon.svg';

  /// File path: assets/svg/receipt.svg
  String get receipt => 'assets/svg/receipt.svg';

  /// File path: assets/svg/recoverp_password.svg
  String get recoverpPassword => 'assets/svg/recoverp_password.svg';

  /// File path: assets/svg/refund.svg
  String get refund => 'assets/svg/refund.svg';

  /// File path: assets/svg/search-home.svg
  String get searchHome => 'assets/svg/search-home.svg';

  /// File path: assets/svg/search.svg
  String get search => 'assets/svg/search.svg';

  /// File path: assets/svg/send-right.svg
  String get sendRight => 'assets/svg/send-right.svg';

  /// File path: assets/svg/share.svg
  String get share => 'assets/svg/share.svg';

  /// File path: assets/svg/share2.svg
  String get share2 => 'assets/svg/share2.svg';

  /// File path: assets/svg/shield-check.svg
  String get shieldCheck => 'assets/svg/shield-check.svg';

  /// File path: assets/svg/shield-times.svg
  String get shieldTimes => 'assets/svg/shield-times.svg';

  /// File path: assets/svg/shopping-bag-alt.svg
  String get shoppingBagAlt => 'assets/svg/shopping-bag-alt.svg';

  /// File path: assets/svg/shopping-cart-plus.svg
  String get shoppingCartPlus => 'assets/svg/shopping-cart-plus.svg';

  /// File path: assets/svg/support.svg
  String get support => 'assets/svg/support.svg';

  /// File path: assets/svg/terms.svg
  String get terms => 'assets/svg/terms.svg';

  /// File path: assets/svg/ticket.svg
  String get ticket => 'assets/svg/ticket.svg';

  /// File path: assets/svg/translate.svg
  String get translate => 'assets/svg/translate.svg';

  /// File path: assets/svg/trash.svg
  String get trash => 'assets/svg/trash.svg';

  /// File path: assets/svg/twitter.svg
  String get twitter => 'assets/svg/twitter.svg';

  /// List of all assets
  List<String> get values => [
        activeBag,
        activeCategories,
        activeFavorite,
        activeHome,
        activeMore,
        activeRadio,
        activeShop,
        activeSupport,
        arrowLeft,
        arrowRight,
        bag,
        blog,
        boxCheck,
        cancelIcon,
        cart,
        cash,
        clock,
        confirmOtp,
        cuppon,
        currency,
        doneIcon,
        edit,
        envelope,
        eye,
        facebook,
        fillLocation,
        filter,
        fire,
        gift,
        grid,
        heart,
        image,
        inactiveBag,
        inactiveCategories,
        inactiveFavorite,
        inactiveHome,
        inactiveMore,
        inactiveShop,
        inactiveSupport,
        key,
        linkedIn,
        list,
        location,
        locationPurple,
        logout,
        messageText,
        message,
        notificationWhite,
        notification,
        phone,
        pinterest,
        privacy,
        profile,
        radio,
        radioIcon,
        receipt,
        recoverpPassword,
        refund,
        searchHome,
        search,
        sendRight,
        share,
        share2,
        shieldCheck,
        shieldTimes,
        shoppingBagAlt,
        shoppingCartPlus,
        support,
        terms,
        ticket,
        translate,
        trash,
        twitter
      ];
}

class Assets {
  const Assets._();

  static const $AssetsJsonGen json = $AssetsJsonGen();
  static const $AssetsPngGen png = $AssetsPngGen();
  static const $AssetsSvgGen svg = $AssetsSvgGen();
}

class AssetGenImage {
  const AssetGenImage(
    this._assetName, {
    this.size,
    this.flavors = const {},
    this.animation,
  });

  final String _assetName;

  final Size? size;
  final Set<String> flavors;
  final AssetGenImageAnimation? animation;

  Image image({
    Key? key,
    AssetBundle? bundle,
    ImageFrameBuilder? frameBuilder,
    ImageErrorWidgetBuilder? errorBuilder,
    String? semanticLabel,
    bool excludeFromSemantics = false,
    double? scale,
    double? width,
    double? height,
    Color? color,
    Animation<double>? opacity,
    BlendMode? colorBlendMode,
    BoxFit? fit,
    AlignmentGeometry alignment = Alignment.center,
    ImageRepeat repeat = ImageRepeat.noRepeat,
    Rect? centerSlice,
    bool matchTextDirection = false,
    bool gaplessPlayback = true,
    bool isAntiAlias = false,
    String? package,
    FilterQuality filterQuality = FilterQuality.medium,
    int? cacheWidth,
    int? cacheHeight,
  }) {
    return Image.asset(
      _assetName,
      key: key,
      bundle: bundle,
      frameBuilder: frameBuilder,
      errorBuilder: errorBuilder,
      semanticLabel: semanticLabel,
      excludeFromSemantics: excludeFromSemantics,
      scale: scale,
      width: width,
      height: height,
      color: color,
      opacity: opacity,
      colorBlendMode: colorBlendMode,
      fit: fit,
      alignment: alignment,
      repeat: repeat,
      centerSlice: centerSlice,
      matchTextDirection: matchTextDirection,
      gaplessPlayback: gaplessPlayback,
      isAntiAlias: isAntiAlias,
      package: package,
      filterQuality: filterQuality,
      cacheWidth: cacheWidth,
      cacheHeight: cacheHeight,
    );
  }

  ImageProvider provider({
    AssetBundle? bundle,
    String? package,
  }) {
    return AssetImage(
      _assetName,
      bundle: bundle,
      package: package,
    );
  }

  String get path => _assetName;

  String get keyName => _assetName;
}

class AssetGenImageAnimation {
  const AssetGenImageAnimation({
    required this.isAnimation,
    required this.duration,
    required this.frames,
  });

  final bool isAnimation;
  final Duration duration;
  final int frames;
}
