import 'package:flutter/material.dart';
import 'package:ready_grocery/views/pharmacy/home/layouts/home_view_layout.dart';

class PharmacyHomeView extends StatelessWidget {
  const PharmacyHomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return const PharmacyHomeViewLayout();
  }
}
