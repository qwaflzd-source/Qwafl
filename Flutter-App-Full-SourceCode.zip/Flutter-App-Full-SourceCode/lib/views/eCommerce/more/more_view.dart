// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:ready_grocery/views/eCommerce/more/layouts/more_layout.dart';

class EcommerceMoreView extends StatelessWidget {
  const EcommerceMoreView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return const EcommerceMoreLayout();
  }
}
