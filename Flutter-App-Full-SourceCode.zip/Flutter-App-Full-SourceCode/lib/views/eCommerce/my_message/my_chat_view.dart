import 'package:flutter/material.dart';
import 'package:ready_grocery/models/eCommerce/shop_message_model/shop.dart';
import 'package:ready_grocery/views/eCommerce/my_message/layouts/my_chat_layout.dart';

class MyChatView extends StatelessWidget {
  final Shop shop;
  const MyChatView({super.key, required this.shop});

  @override
  Widget build(BuildContext context) {
    return MyChatLayout(
      shop: shop,
    );
  }
}
