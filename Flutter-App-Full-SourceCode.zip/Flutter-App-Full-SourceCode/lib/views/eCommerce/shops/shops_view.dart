// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:ready_grocery/views/eCommerce/shops/layouts/shops_layout.dart';

class EcommerceShopsView extends StatelessWidget {
  const EcommerceShopsView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return const EcommerceShopsLayout();
  }
}
