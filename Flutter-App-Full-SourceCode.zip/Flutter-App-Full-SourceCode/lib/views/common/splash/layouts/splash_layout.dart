import 'dart:async';

import 'package:connectivity_wrapper/connectivity_wrapper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:ready_grocery/components/ecommerce/offline.dart';
import 'package:ready_grocery/config/app_constants.dart';
import 'package:ready_grocery/controllers/common/master_controller.dart';
import 'package:ready_grocery/gen/assets.gen.dart';
import 'package:ready_grocery/routes.dart';
import 'package:ready_grocery/services/common/hive_service_provider.dart';
import 'package:ready_grocery/utils/api_client.dart';
import 'package:ready_grocery/utils/context_less_navigation.dart';
import 'package:ready_grocery/utils/global_function.dart';

class SplashLayout extends ConsumerStatefulWidget {
  const SplashLayout({super.key});

  @override
  ConsumerState<SplashLayout> createState() => _SplashLayoutState();
}

class _SplashLayoutState extends ConsumerState<SplashLayout> {
  StreamSubscription<ConnectivityStatus>? _connectivitySubscription;

  @override
  void initState() {
    super.initState();

    _connectivitySubscription =
        ConnectivityWrapper.instance.onStatusChange.listen((event) {
      if (event == ConnectivityStatus.CONNECTED) {
        // Navigate to the login screen after a delay
        ref
            .read(masterControllerProvider.notifier)
            .getMasterData()
            .then((response) {
          if (!mounted) {
            return;
          }
          if (response?.data.themeColors.primaryColor != null) {
            ref.read(hiveServiceProvider).setPrimaryColor(
                color: response!.data.themeColors.primaryColor);
          }
          if (response?.data.appLogo != null) {
            ref
                .read(hiveServiceProvider)
                .setAppLogo(logo: response!.data.appLogo);
          }
          if (response?.data.appName != null) {
            ref
                .read(hiveServiceProvider)
                .setAppName(name: response!.data.appName);
          }
          if (response?.data.splashLogo != null) {
            ref
                .read(hiveServiceProvider)
                .setSplashLogo(splashLogo: response!.data.splashLogo);
          }
        });
        Future.wait([
          ref.read(hiveServiceProvider).loadTokenAndUser(),
        ]).then((data) {
          Future.delayed(const Duration(seconds: 3), () {
            if (!mounted) {
              return;
            }
            if (data.first![0] == true &&
                (data.first![1] == null || data.first![2] == null)) {
              context.nav.pushNamedAndRemoveUntil(
                Routes.getCoreRouteName(AppConstants.appServiceName),
                (route) => false,
              );
            } else if ((data.first![1] != null) && (data.first![2] != null)) {
              ref.read(apiClientProvider).updateToken(token: data.first![1]);
              context.nav.pushNamedAndRemoveUntil(
                Routes.getCoreRouteName(AppConstants.appServiceName),
                (route) => false,
              );
            } else {
              context.nav.pushNamedAndRemoveUntil(
                Routes.getCoreRouteName(AppConstants.appServiceName),
                (route) => false,
              );
            }
          });
        });
      }
    });
  }

  @override
  void dispose() {
    _connectivitySubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ConnectivityWidgetWrapper(
      offlineWidget: const OfflineScreen(),
      child: Scaffold(
        body: Center(
          child: Assets.png.splashLogo.image(
            height: 100.h,
            width: 200.w,
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }
}

Color hexToColor(String hexString) {
  final buffer = StringBuffer();
  if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
  buffer.write(hexString.replaceFirst('#', ''));
  return Color(int.parse(buffer.toString(), radix: 16));
}