import 'package:connectivity_wrapper/connectivity_wrapper.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:ready_grocery/config/app_color.dart';
import 'package:ready_grocery/config/app_constants.dart';
import 'package:ready_grocery/config/theme.dart';
import 'package:ready_grocery/firebase_options.dart';
import 'package:ready_grocery/generated/l10n.dart';
import 'package:ready_grocery/models/eCommerce/cart/hive_cart_model.dart';
import 'package:ready_grocery/routes.dart';
import 'package:ready_grocery/services/common/secure_storage_service.dart';
import 'package:ready_grocery/utils/global_function.dart';
import 'package:ready_grocery/utils/notification_handler.dart';

Future<void> _initAppServices() async {
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint('Firebase init error: $e');
  }

  try {
    await setupFlutterNotifications();
    FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
    firebaseMessagingForgroundHandler();
  } catch (e) {
    debugPrint('Notifications init error: $e');
  }

  try {
    await FlutterDownloader.initialize(
      debug: kDebugMode,
      ignoreSsl: false,
    );
  } catch (e) {
    debugPrint('FlutterDownloader init error: $e');
  }

  try {
    await Hive.initFlutter();
    if (!Hive.isAdapterRegistered(HiveCartModelAdapter().typeId)) {
      Hive.registerAdapter(HiveCartModelAdapter());
    }
    if (!Hive.isBoxOpen(AppConstants.appSettingsBox)) {
      await Hive.openBox(AppConstants.appSettingsBox);
    }
    if (!Hive.isBoxOpen(AppConstants.userBox)) {
      await Hive.openBox(AppConstants.userBox);
    }
    if (!Hive.isBoxOpen(AppConstants.cartModelBox)) {
      await Hive.openBox<HiveCartModel>(AppConstants.cartModelBox);
    }
  } catch (e) {
    debugPrint('Hive init error: $e');
  }

  try {
    await SecureStorageService().bootstrapAuthToken();
  } catch (e) {
    debugPrint('SecureStorage init error: $e');
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kReleaseMode) {
    debugPrint = (String? message, {int? wrapWidth}) {};
  }

  await _initAppServices();

  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  Locale resolveLocal({required String langCode}) {
    return Locale(langCode);
  }

  @override
  Widget build(BuildContext context) {
    final settingsBox = Hive.isBoxOpen(AppConstants.appSettingsBox)
        ? Hive.box(AppConstants.appSettingsBox)
        : null;

    return ScreenUtilInit(
      designSize: const Size(390, 844),
      minTextAdapt: true,
      splitScreenMode: true,
      useInheritedMediaQuery: false,
      builder: (context, child) {
        Widget buildMaterialApp(Box? box) {
          final isDark = (box?.get(AppConstants.isDarkTheme,
              defaultValue: false) as bool?) ?? false;
          final primaryColor = box?.get(AppConstants.primaryColor);
          if (primaryColor != null) {
            EcommerceAppColor.primary = hexToColor(primaryColor);
          }
          GlobalFunction.changeStatusBarTheme(isDark: isDark);
          final appLocal = box?.get(AppConstants.appLocal) as String?;

          return ConnectivityAppWrapper(
            app: MaterialApp(
              showPerformanceOverlay: false,
              debugShowCheckedModeBanner: false,
              title: 'Ready Grocery',
              navigatorKey: GlobalFunction.navigatorKey,
              locale: resolveLocal(langCode: appLocal ?? 'ar'),
              localizationsDelegates: const [
                S.delegate,
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
                GlobalCupertinoLocalizations.delegate,
              ],
              supportedLocales: S.delegate.supportedLocales,
              theme: getAppTheme(context: context, isDarkTheme: isDark),
              onGenerateRoute: generatedRoutes,
              initialRoute: Routes.splash,
            ),
          );
        }

        if (settingsBox == null) {
          return buildMaterialApp(null);
        }

        return ValueListenableBuilder(
          valueListenable: settingsBox.listenable(),
          builder: (context, box, _) => buildMaterialApp(box),
        );
      },
    );
  }
}
