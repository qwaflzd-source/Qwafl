import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:ready_grocery/config/app_constants.dart';

class SecureStorageService {
  SecureStorageService._internal();

  factory SecureStorageService() => _instance;

  static final SecureStorageService _instance =
      SecureStorageService._internal();

  static const FlutterSecureStorage _storage = FlutterSecureStorage(
    iOptions: IOSOptions(
      accessibility: KeychainAccessibility.first_unlock,
    ),
  );

  String? _cachedAuthToken;

  String? get cachedAuthToken => _cachedAuthToken;

  Future<void> bootstrapAuthToken() async {
    final secureToken =
        await _storage.read(key: AppConstants.secureAuthTokenKey);
    if (secureToken != null && secureToken.isNotEmpty) {
      _cachedAuthToken = secureToken;
      if (await Hive.boxExists(AppConstants.authBox)) {
        final authBox = await Hive.openBox(AppConstants.authBox);
        await authBox.delete(AppConstants.authToken);
      }
      return;
    }

    if (await Hive.boxExists(AppConstants.authBox)) {
      final authBox = await Hive.openBox(AppConstants.authBox);
      final legacyToken = authBox.get(AppConstants.authToken) as String?;
      if (legacyToken != null && legacyToken.isNotEmpty) {
        await _storage.write(
          key: AppConstants.secureAuthTokenKey,
          value: legacyToken,
        );
        await authBox.delete(AppConstants.authToken);
        _cachedAuthToken = legacyToken;
        return;
      }
    }

    _cachedAuthToken = null;
  }

  Future<void> saveAuthToken(String token) async {
    _cachedAuthToken = token;
    await _storage.write(
      key: AppConstants.secureAuthTokenKey,
      value: token,
    );
  }

  Future<String?> getAuthToken() async {
    if (_cachedAuthToken != null && _cachedAuthToken!.isNotEmpty) {
      return _cachedAuthToken;
    }
    _cachedAuthToken =
        await _storage.read(key: AppConstants.secureAuthTokenKey);
    return _cachedAuthToken;
  }

  bool hasAuthToken() =>
      _cachedAuthToken != null && _cachedAuthToken!.isNotEmpty;

  Future<void> deleteAuthToken() async {
    _cachedAuthToken = null;
    await _storage.delete(key: AppConstants.secureAuthTokenKey);
    if (await Hive.boxExists(AppConstants.authBox)) {
      final authBox = await Hive.openBox(AppConstants.authBox);
      await authBox.delete(AppConstants.authToken);
    }
  }
}

final secureStorageServiceProvider = Provider((ref) => SecureStorageService());
