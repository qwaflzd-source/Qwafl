# Ready Grocery Customer App

Ready Grocery is a Flutter customer application for grocery and multi-vendor commerce. It includes authentication, catalog browsing, cart and checkout, order history, profile management, notifications, and in-app customer messaging for Android and iOS.

## Overview

This project is organized for marketplace delivery and client customization. The UI is driven by REST APIs, Riverpod state management, and reusable feature modules so buyers can connect their own backend, Firebase project, and branding with minimal code changes.

## Core Features

- Secure authentication token storage with `flutter_secure_storage`
- Product, category, shop, banner, and flash sale browsing
- Favorites, cart management, buy-now flow, and voucher support
- Checkout, address management, order placement, and order history
- Profile update, password change, and password recovery with OTP
- Firebase push notifications and Pusher-powered real-time messaging
- Multi-language support and persisted theme and locale settings

## Tech Stack

- Flutter 3.5+
- Dart 3.5+
- Riverpod for state management
- Dio for networking
- Hive for non-sensitive local caching
- Firebase Messaging for push notifications
- Pusher Channels for chat events

## Installation

1. Open the project in Android Studio or VS Code.
2. Install dependencies:

```bash
flutter pub get
```

3. Regenerate localization or generated files if you change ARB/assets:

```bash
flutter pub run intl_utils:generate
dart run build_runner build --delete-conflicting-outputs
```

4. Run the application:

```bash
flutter run
```

## Configuration

Update these files before production use:

- `lib/config/app_constants.dart`
- `lib/firebase_options.dart`
- `android/app/google-services.json`
- `ios/Runner/GoogleService-Info.plist`
- `android/key.properties`

Required environment changes:

- Replace the API base URL with your backend endpoint.
- Replace Firebase configuration with your own project values.
- Replace the Pusher key and cluster if you use a different realtime setup.
- Add your own Android release keystore and iOS signing team.

## Security

- Authentication tokens are stored in platform-secure storage, not Hive.
- Hive is used only for non-sensitive cached app data such as theme and locale.
- Logout clears secure token storage and local cached user data.
- Do not ship the app with personal signing keys or private infrastructure credentials.

## Build Instructions

### Android

```bash
flutter build apk --release
```

```bash
flutter build appbundle --release
```

Notes:

- `compileSdk` and `targetSdk` are set to 36.
- Add your own values to `android/key.properties` to generate a production-signed artifact.

### iOS

```bash
flutter build ios --release
```

Notes:

- Open `ios/Runner.xcworkspace` in Xcode for signing configuration.
- Add your own Apple Developer team and provisioning profile.

## Folder Structure

```text
lib/
  components/    Shared widgets
  config/        Constants, theme, colors, typography
  controllers/   Riverpod business logic
  generated/     Localization outputs
  models/        API and local data models
  services/      Network and persistence layers
  utils/         Helpers, notification setup, API client
  views/         Screens and layouts
assets/
  font/          Custom fonts
  json/          Static JSON resources
  png/           Raster assets
  svg/           Vector assets
android/         Android host app and Gradle config
ios/             iOS host app and Xcode config
```

## Backend Expectations

The backend should provide endpoints for:

- Authentication and OTP flows
- Master settings and app branding
- Categories, shops, products, and product details
- Cart, vouchers, checkout, and order placement
- Orders, reviews, notifications, and messaging
- Support, legal pages, and profile management

## Key Dependencies

- `flutter_riverpod`
- `dio`
- `hive` and `hive_flutter`
- `flutter_secure_storage`
- `firebase_core` and `firebase_messaging`
- `flutter_local_notifications`
- `pusher_channels_flutter`
- `cached_network_image`
- `flutter_inappwebview`

## Troubleshooting

### Unauthorized after login

- Confirm the backend returns a token at `data.access.token`.
- Clear old app data if migrating from a version that stored tokens outside secure storage.

### Notifications are not received

- Verify Firebase files match the current Android and iOS package identifiers.
- Confirm FCM is enabled in the Firebase project.

### Release build fails

- Make sure Android SDK 36 is installed.
- Confirm signing files and Firebase config files are present.
- Run `flutter clean` and `flutter pub get` before rebuilding.

## Support

Support should be provided through the marketplace support channel included with your item listing.

Please include:

- Flutter version
- Device model and OS version
- Platform: Android or iOS
- Clear reproduction steps
- Relevant logs or screenshots

## Delivery Notes

- This package contains the customer app only.
- Backend, admin panel, and deployment infrastructure are separate deliverables.
- Replace demo branding, Firebase setup, and signing credentials before publishing to app stores.
